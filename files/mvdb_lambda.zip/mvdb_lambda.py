import boto3
import os
import json
from datetime import datetime
from botocore.exceptions import ClientError

table_name = os.environ['TABLE_NAME']
dynamo = boto3.resource('dynamodb').Table(table_name)


def lambda_handler(event, context):
    print("Table name: {0}".format(table_name))
    print("Received event: " + json.dumps(event, indent=2))
    print("#################################################")
    print("Year to look for {0}".format(
        event['queryStringParameters']['year']))

    # operation = event['operation']
    operation = event['httpMethod'].lower()

    try:
        if operation == 'get':
            result = dynamo.get_item(
                Key={
                    'year': event['queryStringParameters']['year'],
                    'title': event['queryStringParameters']['title']
                }
            )

    #     operations = {
    #         'put': lambda x: dynamo.put_item(**x),
    #         'post': lambda x: dynamo.put_item(**x),
    #         'get': lambda x: dynamo.get_item(**x),
    #         'update': lambda x: dynamo.update_item(**x),
    #         'delete': lambda x: dynamo.delete_item(**x),
    #         'scan': lambda x: dynamo.scan(**x),
    #         'echo': lambda x: x,
    #         'ping': lambda x: 'pong'
    #     }

    #     # if operation == 'get':
    #     #     payload = {"Key": event['queryStringParameters']}

    #     if operation in operations:
    #         # return operations[operation](event.get('queryStringParameters'))
    #         return operations[operation](event.get('payload'))
    #     else:
    #         raise ValueError('Unrecognized operation "{}"'.format(operation))

    except ClientError as e:
        print(e.response['Error']['Message'])

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(result['Item'])
    }
