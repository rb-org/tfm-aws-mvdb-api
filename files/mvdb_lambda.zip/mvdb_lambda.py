import boto3
import os
import json
from datetime import datetime


def lambda_handler(event, context):
    if 'TableName' not in event:
        raise Exception("No table name specified.")
    table_name = event['TableName']

    print(table_name)
